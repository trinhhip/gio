<?php
/**
 * Project: Multi Vendor
 * User: jing
 * Date: 2019-07-31
 * Time: 18:00
 */
namespace Omnyfy\VendorSignUp\Controller\Index;

use Magento\Framework\View\Result\PageFactory;

class Type extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        // TODO: Implement execute() method.
    }
}
 